(function () {
	"use strict";

	// --- MAGNIFIER LOGIC ---
	function startMagnifier(pickrInstance) {
		document.body.style.cursor = "wait";

		html2canvas(document.body, {
			useCORS: true,
			logging: false,
			scale: 1,
			x: window.scrollX,
			y: window.scrollY,
			width: window.innerWidth,
			height: window.innerHeight,
		})
			.then((pageCanvas) => {
				document.body.style.cursor = "default";
				const overlay = document.createElement("div");
				overlay.id = "zen-magnifier-overlay";
				const lens = document.createElement("div");
				lens.id = "zen-magnifier-lens";
				const canvas = document.createElement("canvas");
				canvas.id = "zen-magnifier-canvas";
				canvas.width = 150;
				canvas.height = 150;
				const ctx = canvas.getContext("2d");
				ctx.imageSmoothingEnabled = false;
				const grid = document.createElement("div");
				grid.id = "zen-magnifier-grid";
				const selector = document.createElement("div");
				selector.id = "zen-magnifier-selector";
				const text = document.createElement("div");
				text.id = "zen-magnifier-text";

				lens.append(canvas, grid, selector, text);
				overlay.append(lens);
				document.body.append(overlay);

				const pixelCtx = pageCanvas.getContext("2d");
				const updateLens = (e) => {
					const x = e.clientX;
					const y = e.clientY;
					lens.style.left = x + "px";
					lens.style.top = y + "px";
					const offset = 7;
					const srcX = x + window.scrollX - offset;
					const srcY = y + window.scrollY - offset;
					ctx.clearRect(0, 0, canvas.width, canvas.height);
					ctx.drawImage(pageCanvas, srcX, srcY, 15, 15, 0, 0, 150, 150);
					const p = pixelCtx.getImageData(x + window.scrollX, y + window.scrollY, 1, 1).data;
					const hex = "#" + ((1 << 24) + (p[0] << 16) + (p[1] << 8) + p[2]).toString(16).slice(1).toUpperCase();
					text.innerText = hex;
				};
				const pickColor = (e) => {
					const x = e.clientX;
					const y = e.clientY;
					const p = pixelCtx.getImageData(x + window.scrollX, y + window.scrollY, 1, 1).data;
					const hex = "#" + ((1 << 24) + (p[0] << 16) + (p[1] << 8) + p[2]).toString(16).slice(1);
					pickrInstance.setColor(hex);
					navigator.clipboard.writeText(hex);
					overlay.remove();
					document.removeEventListener("mousemove", updateLens);
				};
				overlay.addEventListener("click", pickColor);
				document.addEventListener("mousemove", updateLens);
			})
			.catch((err) => {
				document.body.style.cursor = "default";
				// If CORS fails (on some sites), use the simple picker logic
				console.log("Magnifier restricted by CORS.");
			});
	}

	// --- DRAG LOGIC ---
	function makeDraggable(el, handle) {
		let isDragging = false,
			startX,
			startY,
			initialLeft,
			initialTop;
		handle.addEventListener("mousedown", (e) => {
			isDragging = true;
			startX = e.clientX;
			startY = e.clientY;
			const rect = el.getBoundingClientRect();
			initialLeft = rect.left;
			initialTop = rect.top;
			el.style.position = "fixed";
			el.style.left = `${initialLeft}px`;
			el.style.top = `${initialTop}px`;
			el.style.transform = "none";
			document.body.style.userSelect = "none";
		});
		document.addEventListener("mousemove", (e) => {
			if (!isDragging) return;
			el.style.left = `${initialLeft + (e.clientX - startX)}px`;
			el.style.top = `${initialTop + (e.clientY - startY)}px`;
		});
		document.addEventListener("mouseup", () => {
			isDragging = false;
			document.body.style.userSelect = "";
		});
	}

	function checkContrast(colorInput, inputEl) {
		let r = 0,
			g = 0,
			b = 0,
			a = 1;
		if (colorInput && typeof colorInput.toRGBA === "function") {
			const rgba = colorInput.toRGBA();
			r = rgba[0];
			g = rgba[1];
			b = rgba[2];
			a = rgba[3];
		} else if (typeof colorInput === "string" && colorInput.startsWith("#")) {
			const hex = colorInput.replace("#", "");
			if (hex.length >= 6) {
				r = parseInt(hex.substring(0, 2), 16);
				g = parseInt(hex.substring(2, 4), 16);
				b = parseInt(hex.substring(4, 6), 16);
				if (hex.length === 8) a = parseInt(hex.substring(6, 8), 16) / 255;
			}
		}
		const brightness = Math.round((r * 299 + g * 587 + b * 114) / 1000);
		if (brightness > 140 || a < 0.38) inputEl.classList.add("zen-icon-black");
		else inputEl.classList.remove("zen-icon-black");
	}

	// --- INIT ---
	function initColorPicker(input) {
		if (input.dataset.zenReady) return;
		input.dataset.zenReady = "true";

		let originalColor = input.value || "#000000";
		const startColor = originalColor;

		input.setAttribute("type", "text");
		input.classList.add("zen-text-hide");
		input.classList.add("zen-trigger-default");
		input.style.backgroundColor = startColor;
		input.value = startColor;
		checkContrast(startColor, input);

		const pickr = Pickr.create({
			el: input,
			theme: "classic",
			default: startColor,
			useAsButton: true,
			padding: 8,
			components: {
				preview: true,
				opacity: true,
				hue: true,
				interaction: { hex: true, rgba: true, hsla: true, input: true, cancel: true, save: true },
			},
			i18n: { "btn:save": "Apply", "btn:cancel": "Cancel" },
		});

		pickr.on("init", (instance) => {
			const app = instance._root.app;
			const handle = document.createElement("div");
			handle.className = "zen-drag-handle";
			app.prepend(handle);
			makeDraggable(app, handle);

			setTimeout(() => {
				const interactionBox = instance._root.interaction.result.parentNode;

				const rowTop = document.createElement("div");
				rowTop.className = "zen-row-top";
				const rowBottom = document.createElement("div");
				rowBottom.className = "zen-row-bottom";
				const groupLeft = document.createElement("div");
				groupLeft.className = "zen-group-left";
				const groupRight = document.createElement("div");
				groupRight.className = "zen-group-right";

				const eyeBtn = document.createElement("div");
				eyeBtn.className = "zen-eyedropper-btn";
				eyeBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 16 16"><path fill="currentColor" d="M15 1c-1.8-1.8-3.7-0.7-4.6 0.1-0.4 0.4-0.7 0.9-0.7 1.5v0c0 1.1-1.1 1.8-2.1 1.5l-0.1-0.1-0.7 0.8 0.7 0.7-6 6-0.8 2.3-0.7 0.7 1.5 1.5 0.8-0.8 2.3-0.8 6-6 0.7 0.7 0.7-0.6-0.1-0.2c-0.3-1 0.4-2.1 1.5-2.1v0c0.6 0 1.1-0.2 1.4-0.6 0.9-0.9 2-2.8 0.2-4.6zM3.9 13.6l-2 0.7-0.2 0.1 0.1-0.2 0.7-2 5.8-5.8 1.5 1.5-5.9 5.7z"/></svg>`;

				eyeBtn.addEventListener("click", () => {
					if (window.EyeDropper) {
						new EyeDropper()
							.open()
							.then((r) => {
								pickr.setColor(r.sRGBHex);
								navigator.clipboard.writeText(r.sRGBHex);
							})
							.catch(() => {});
					} else {
						startMagnifier(pickr);
					}
				});

				rowTop.appendChild(instance._root.interaction.result);
				rowTop.appendChild(eyeBtn);
				instance._root.interaction.options.forEach((btn) => groupLeft.appendChild(btn));
				groupRight.appendChild(instance._root.interaction.cancel);
				groupRight.appendChild(instance._root.interaction.save);
				rowBottom.appendChild(groupLeft);
				rowBottom.appendChild(groupRight);
				interactionBox.appendChild(rowTop);
				interactionBox.appendChild(rowBottom);

				const cleanValue = () => {
					const val = instance._root.interaction.result.value;
					if (val.startsWith("rgba(")) instance._root.interaction.result.value = val.replace("rgba(", "").replace(")", "");
					else if (val.startsWith("hsla(")) instance._root.interaction.result.value = val.replace("hsla(", "").replace(")", "");
				};
				pickr.on("change", () => setTimeout(cleanValue, 0));
				instance._root.interaction.options.forEach((btn) => btn.addEventListener("click", () => setTimeout(cleanValue, 0)));
				instance._root.interaction.result.addEventListener("change", (e) => {
					const raw = e.target.value.trim();
					if (/^[0-9\.,\s%]+$/.test(raw)) {
						if (!pickr.setColor(`rgba(${raw})`)) pickr.setColor(`hsla(${raw})`);
					}
				});
			}, 10);
		});

		pickr.on("change", (color) => {
			const hex = color.toHEXA().toString();
			input.style.backgroundColor = hex;
			checkContrast(color, input);
			input.value = color.a < 1 ? hex : hex.substring(0, 7);
			input.dispatchEvent(new Event("input", { bubbles: true }));
			input.dispatchEvent(new Event("change", { bubbles: true }));
		});

		pickr.on("cancel", () => {
			input.style.backgroundColor = originalColor;
			input.value = originalColor;
			checkContrast(originalColor, input);
			input.dispatchEvent(new Event("input", { bubbles: true }));
			input.dispatchEvent(new Event("change", { bubbles: true }));
			pickr.hide();
		});

		pickr.on("save", (color) => {
			originalColor = color.toHEXA().toString();
			pickr.hide();
		});
	}

	const observer = new MutationObserver((mutations) => {
		mutations.forEach((m) => {
			m.addedNodes.forEach((node) => {
				if (node.nodeType === 1) {
					if (node.tagName === "INPUT" && node.getAttribute("type") === "color") initColorPicker(node);
					node.querySelectorAll?.('input[type="color"]').forEach(initColorPicker);
				}
			});
		});
	});

	if (document.body) {
		observer.observe(document.body, { childList: true, subtree: true });
		document.querySelectorAll('input[type="color"]').forEach(initColorPicker);
	}
})();
